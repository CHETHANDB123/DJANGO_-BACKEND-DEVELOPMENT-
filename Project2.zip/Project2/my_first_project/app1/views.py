from django.http import HttpResponse
def home_view(request):
    return HttpResponse("This is my first project")

def register_view(request):
    return HttpResponse("This is the registration page")

def profile_view(request):
    return HttpResponse("This is the profile page")
'''
<html>
<head>
<title>My First Profile Page</title>
<style>
.main-container{
background-color: aqua;
}
</style>
</head>
<body>
<div class="main-container">
<h1>
welcome to profile page</h1>
<hr>
<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</div>
</body>
</html>
'''
