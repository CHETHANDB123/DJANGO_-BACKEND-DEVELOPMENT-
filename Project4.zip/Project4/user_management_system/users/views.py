from django.shortcuts import render

def home_view(request):
    response=render(request,'home.html')
    return response

def profile_view(request):
    details={
        "name":"chethan",
        "age":22,
        "city":"bangalore"
    }
    documents={
        "adhaar_no":"345 678 966",
        "bank_acc":"23456789088",
        "pan_no":"PAN345678"
    }
    return render(request,"profile.html",context=details)