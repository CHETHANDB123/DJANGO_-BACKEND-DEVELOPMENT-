from django.http import HttpResponse
def diwali_sale_view(request):
    return HttpResponse("<h1> Diwali Offers</h1>")
def new_year_sale_view(request):
    return HttpResponse("<h1> New Year Offer </h1>")