from django.urls import path
from . import views

urlpatterns=[
    path('offers_diwali_sale/',views.diwali_sale_view),
    path('offers_new_year_sale/',views.new_year_sale_view),
    
]