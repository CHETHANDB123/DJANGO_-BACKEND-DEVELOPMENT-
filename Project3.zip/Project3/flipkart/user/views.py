from django.http import HttpResponse
def register_view(request):
    return HttpResponse("<h1>Registration done</h1>")
def login_view(requset):
    return HttpResponse("<h1>Login Page</h1>")
def profile_page_view(request):
    return HttpResponse("<h1> Profile Page</h1>")