"""
URL configuration for flipkart project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
# from user import views as v1
# from products import views as v2
# from offers import views as v3

urlpatterns = [
    #routes for user
    path('admin/', admin.site.urls),
    path('user/',include('user.urls')),
   
    #route for products
    path('products/',include('products.urls')),

    #routes for offers
    path('offers/',include('offers.urls')),
   
]
