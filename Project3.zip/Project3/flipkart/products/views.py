from django.http import HttpResponse
def electronics_products(request):
    return HttpResponse("<h1>Electronics Products</h1>")
def fashion_products(request):
    return HttpResponse("<h1>Fashion Products</h1>")