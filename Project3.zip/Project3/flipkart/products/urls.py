from django.urls import path
from . import views

urlpatterns=[
    path('products_electronics/',views.electronics_products),
    path('products_fashion/',views.fashion_products),
   
]